# Installing the Packages
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score
from sklearn.svm import SVC
from sklearn.svm import LinearSVC
from sklearn import preprocessing
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import classification_report, confusion_matrix

#Read the NBA CSV file and return a Pandas DataFrame.


National_basketball_data = pd.read_csv('./nba2021.csv')

# storing the orginial dataset column names.
original_headers = list(National_basketball_data.columns.values)

# Pre-Processing the dataset though noticed that most of the dataset is already processed.
#This will reduce the errors on bench players and players who played zero minutes, conditions are applied to original dataset and select only those records that apply.
class_column = 'Pos'
National_basketball_data.fillna(value=0, inplace=True)
National_basketball_data.dropna(inplace=True)
#print("Shape of National Basket ball data: {}".format(National_basketball_data.shape))
#The features such as Age, player name and team name which are not important at all. so it is removed, following attributes are selected.
feature_columns = ['G','FT', 'FG%', '3P', '3PA', '3P%', '2P%','2P', 'eFG%', 'ORB', 'DRB', 'TRB','AST', 'STL', 'BLK','PTS']


#Pandas DataFrame allows to select the columns, used column selection to split the data into features and class.
National_basketball_data_feature = National_basketball_data[feature_columns]
National_basketball_data_class = National_basketball_data[class_column]


#For training we use 75% data, for testing we consider 25% data 
train_feature, test_feature, train_class, test_class = train_test_split( National_basketball_data_feature, National_basketball_data_class, stratify=National_basketball_data_class, train_size=0.75, test_size=0.25)


# Task 1. Support vector machine algorithm is used to build a model to fit the training data from above.

linearsvm = LinearSVC(dual=False).fit(train_feature, train_class)


#Task 2. Printing Training and Testing Accuracy

print("Training set score: {:.3f}".format(linearsvm.score(train_feature, train_class)))

print("Accuracy Test set score: {:.3f}".format(linearsvm.score(test_feature, test_class)))
prediction = linearsvm.predict(test_feature)

# Task 3. Printing Confusion matrix
print("Confusion matrix:")
print(pd.crosstab(test_class, prediction, rownames=['True'], colnames=['Predicted'], margins=True))


# Task 4. Applying 10-fold stratified cross-validation instead of 75-25% split.
scores = cross_val_score(linearsvm, National_basketball_data_feature, National_basketball_data_class, cv=10)


#Task 5. Printing accuracy of each fold.
print("Cross-validation scores: {}".format(scores))

#Printing average accuracy.
print("Average Accuracy cross-validation score: {:.2f}%".format(scores.mean()*100))

#Performing HyperTuning for better Accuracy.
# training the model on train set
model = SVC()
model.fit(train_feature, train_class)
  
# print prediction results
predictions = model.predict(train_feature)
print(classification_report(train_class, predictions))
param_grid = {'C': [0.1, 1, 10, 100, 1000], 
              'gamma': [1, 0.1, 0.01, 0.001, 0.0001],
              'kernel': ['rbf']} 
  
grid = GridSearchCV(SVC(), param_grid, refit = True, verbose = 3)
  
# fitting the model for grid search
grid.fit(train_feature, train_class)

# printing the best parameter after tuning
print(grid.best_params_)

# printing how our model looks after hyper-parameter tuning
print(grid.best_estimator_)

grid_predictions = grid.predict(train_feature)

# printing classification report
print(classification_report(train_class, grid_predictions))
print("Accuracy score: {:.3f}%".format(grid.score(test_feature,test_class)*100))
